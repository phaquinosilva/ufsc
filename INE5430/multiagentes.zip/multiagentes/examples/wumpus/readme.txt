see wumpus.mas2j for more information
