package revisaoprova;

import java.util.Scanner;
//1049
public class Animal {
	public static void main (String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		String[] palavra = new String[3];
		for (int i = 0; i < palavra.length; i ++) {
			palavra[i] = in.next();
		}
		
		if (palavra[0].equals("vertebrado")) {
			if (palavra[1].equals("ave")) {
				if (palavra[2].equals("carnivoro")) {
					System.out.print("aguia");
				} else if (palavra[2].equals("onivoro")) {
					System.out.print("pomba");
				}
			} else if (palavra[1].equals("mamifero")) {
				if (palavra[2].equals("onivoro")) {
					System.out.print("homem");
				} else if (palavra[2].equals("herbivoro")) {
					System.out.print("vaca");
				}
			}
		} else if (palavra[0].equals("invertebrado")) {
			if(palavra[1].equals("inseto")) {
				if (palavra[2].equals("hematofago")) {
					System.out.print("pulga");
				} else if (palavra[2].equals("herbivoro")) {
					System.out.print("lagarta");
				}
			} else if (palavra[1].equals("anelideo")) {
				if (palavra[2].equals("hematofago")) {
					System.out.print("sanguessuga");
				} else if (palavra[2].equals("onivoro")) {
					System.out.print("minhoca");
				}
			}
		}
		
		System.out.println();
	}
}
