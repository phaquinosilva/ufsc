package prova;

import java.util.ArrayList;

public class Cinema {
	private String nome;
	private String endereco;
	private ArrayList<Funcionario> lstFuncionarios;
	private ArrayList<Sala> lstSalas;
	private ArrayList<Filme> lstFilmes;
	private ArrayList<Sessao> lstSessoes;
	
	Cinema(String nome) {
		this.setNome(nome);
		lstFuncionarios = new ArrayList<Funcionario>();
		lstSalas = new ArrayList<Sala>();
		lstFilmes = new ArrayList<Filme>();
		lstSessoes = new ArrayList<Sessao>();
	}
	
	//getter e setters
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	//metodos pra adicionar nas listas
	public void addFuncionario (Funcionario func) {
		lstFuncionarios.add(func);
	}
	public void addSala (Sala sala) {
		lstSalas.add(sala);
	}
	public void addFilme (Filme filme) {
		lstFilmes.add(filme);
	}
	public void addSessao (Sessao sess) {
		lstSessoes.add(sess);
	}
	
	//outros metodos
	public double precoSessaoMaisCara() {
		double maiorPreco = 0;
		
		for(Sessao s: lstSessoes) {
			//pego o preco do filme da sessao atual
			double precoAtual = s.getFilmeExibicao().getPreco();
			
			//verifico se o preco e maior
			if(precoAtual > maiorPreco) {
				maiorPreco = precoAtual;
			}
		}
		
		return maiorPreco;
	}
	
	public ArrayList<Filme> filmesComedia() {
		ArrayList<Filme> lstComedias = new ArrayList<Filme>();
		
		//adiciono so os filme de comedia
		for(Filme f: lstFilmes) {
			if (f.getGenero().equals("comedia")) {
				lstComedias.add(f);
			}
		}
		
		return lstComedias;
	}
	
	public String generoMaiorSessoes() {
		String generoMaior = "";//qualquer inicializacao
		int qtdeMaiorgeneros = 0;
		
		for(int i=0; i<lstFilmes.size()-1; i++) {
			int qtdeGenerosIguais = 1;
			String generoPesquisa = lstFilmes.get(i).getGenero();
			
			//conto a quantide de filmes de mesmo genero no resto da lista
			for(int j=i+1; j<lstFilmes.size(); j++) {
				//comparo se os dois generos sao iguais
				if(generoPesquisa.equals(lstFilmes.get(j).getGenero())) {
					qtdeGenerosIguais++;
				}
			}
			
			//se for maior a quantidade atual eu troco os maiores
			if(qtdeGenerosIguais > qtdeMaiorgeneros) {
				qtdeMaiorgeneros = qtdeGenerosIguais;
				generoMaior = generoPesquisa;
			}
		}
		
		return generoMaior;
	}
	
	public double valorMaximoDia() {
		int capacidadeTotal = 0;	
		//calculo a capacidade total de todas as salas juntas
		for(Sala sala: lstSalas) {
			capacidadeTotal += sala.getCapacidade();
		}
		
		//calculo o preco de todas as sessoes exibindo o filme mais caro
		double precoTotal = capacidadeTotal*precoSessaoMaisCara();
		
		return precoTotal;
	}
	
}
