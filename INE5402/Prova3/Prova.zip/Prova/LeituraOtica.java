package provaUri;

import java.util.Scanner;

//1129
public class LeituraOtica {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int qtdeEntrada = input.nextInt();

		//salvo se for preto(1) ou branco(0)
		byte[] alternativas = new byte[5];
		
		while(qtdeEntrada != 0) {
			for (int i=0; i<qtdeEntrada; i++) {
				//preenche o vetor (A ate E)
				for(int j=0; j<5; j++) {
					//verifico se e preto ou branco
					int porcentOtica = input.nextInt();
					
					//preto
				 	if(porcentOtica >= 0 && porcentOtica <= 127) {
				 		alternativas[j] = 1;
				 	}
				 	//branco
				 	if(porcentOtica > 127 && porcentOtica <= 255) {
				 		alternativas[j] = 0;	
				 	}
				}
				
				//verifico se nada ou mais de uma assinalada
				int qtdeAlternativasAssinaladas = 0;
				for (byte b: alternativas) {
					qtdeAlternativasAssinaladas += b;
				}
				
				//se tiver diferente de 1
				if (qtdeAlternativasAssinaladas != 1) {
					System.out.printf("*\n");
				}
				//se tiver so uma assinalada
				else {
					//descubro qual das questoes
					int qualAssinalada = 0; //inicializacao aleatoria
					for (int k=0; k<alternativas.length; k++) {
						if(alternativas[k] == 1) {
							qualAssinalada = k;
						}
					}
					
					char resp = ' ';
					if(qualAssinalada == 0) {
						resp = 'A';
					}
					if(qualAssinalada == 1) {
						resp = 'B';
					}	
					if(qualAssinalada == 2) {
						resp = 'C';
					}	
					if(qualAssinalada == 3) {
						resp = 'D';
					}
					if(qualAssinalada == 4) {
						resp = 'E';
					}
					
					System.out.printf("%c\n", resp);
				}
			}
			
			//verifica o proximo
			qtdeEntrada = input.nextInt();
		}
	}
}