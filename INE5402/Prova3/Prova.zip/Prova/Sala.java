package prova;

public class Sala {
	private int codigo;
	private int capacidade;
	
	Sala(int codigo, int capacidade) {
		setCodigo(codigo);
		setCapacidade(capacidade);
	}
	
	//getters e setters
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCapacidade() {
		return capacidade;
	}
	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}
	
}
