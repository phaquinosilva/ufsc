
public class Domino {
	

	private boolean[] usada;
	private int[] sequencia;
	
	public void resolveDomino (int[] ladoA, int[] ladoB) {
		usada = new boolean[ladoA.length];
		sequencia = new int[ladoA.length + ladoB.length];
		if (backtrack(usada, ladoA, ladoB, 0)) {
			for (int i = 0; i < sequencia.length; i++) {
				System.out.printf("[%d | %d]", sequencia[i], sequencia[i+1]);
				i += 1;
			}
		} else {
			System.out.println("� imposs�vel resolver");
		}
	}
	
	public boolean tudousada() {
		for (int i = 0; i < usada.length; i++) {
			if (!usada[i]) {
				return false;
			}
		}
		return true;
	}
	
	public boolean ehSalvo(int[] ladoA, int[] ladoB, int posicao, int i) {
		if (posicao <= 0) {
			return true;
		} else if (ladoA[i] == sequencia[posicao - 1]) {
			return true;
		}
		return false;
	}
	
	
	
	public boolean backtrack (boolean[] usada, int[] ladoA, int[] ladoB, int posicao) {
		if (tudousada()) {
			return true;
		} else {
			for (int i = 0; i < ladoA.length; i++) {
				if (ehSalvo(ladoA, ladoB, posicao, i) && !usada[i]) {
					sequencia[posicao] = ladoA[i];
					sequencia[posicao + 1] = ladoB[i];
					usada[i] = true;
					if (backtrack(usada, ladoA, ladoB, posicao + 2)) {
						return true;
					} else {
						int temp = ladoA[i];
						ladoA[i] = ladoB[i];
						ladoB[i] = temp;
						sequencia[posicao] = 0;
						sequencia[posicao + 1] = 0;
						usada[i] = false;
					}
				}
			}
			return false;
		}
	}
	
	
}
