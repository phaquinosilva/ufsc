
public class TesteDomino {
	
	public static void main (String[] args) {
		/* resultado impossivel
		int[] ladoA = {1,2,3,5,2,1};
		int[] ladoB = {2,3,3,5,4,5};
		*/
		//resultado funcional
		int[] ladoA = {2,4,1,4,2,1};
		int[] ladoB = {1,3,3,5,4,5};
		
		Domino dom = new Domino();
		dom.resolveDomino(ladoA, ladoB);
	}
}
