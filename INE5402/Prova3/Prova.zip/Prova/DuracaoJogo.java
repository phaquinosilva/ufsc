package revisaoprova;

import java.util.Scanner;
import java.io.IOException;

//1047
public class DuracaoJogo {
	
	public static void main (String[] args) throws IOException {
		Scanner in = new Scanner(System.in);
		
		int ent[] = new int [4];
		
		for (int i=0; i<4; i++) {
			ent[i] = in.nextInt();
		}
		
		int minAtual = (ent[0]*60)+ent[1];
		int minFinal = (ent[2]*60)+ent[3];
		
		if (minFinal <= minAtual) {
			minFinal += 24*60;
		}
		
		int horas = (minFinal - minAtual)/60;
		int minutos = (minFinal - minAtual)%60;
		
		System.out.printf("O JOGO DUROU %d HORA(S) E %d MINUTO(S)" , horas, minutos);
		System.out.println();
		
	}
}