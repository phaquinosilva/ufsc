package revisaoprova;


import java.util.Scanner;

//1021
public class NotasMoedas {

	public static void main (String[] args) {
		Scanner in = new Scanner(System.in);
		

		String entrada = in.next(); 
		double n = Double.parseDouble(entrada);
		
		double N = n; //= in.nextDouble();
		
		//notas 100
		int nota100, nota50, nota20, nota10, nota5, nota2;
		int moeda100, moeda50, moeda25, moeda10, moeda5, moeda1;
		 
		nota100 = (int) (N/100);
		N = N%100;
		nota50 = (int) (N/50);
		N = N%50;
		nota20 = (int) (N/20);
		N = N%20;
		nota10 = (int) (N/10);
		N = N%10;
		nota5 = (int) (N/5);
		N = N%5;
		nota2 = (int) (N/2);
		N = (N%2)*100; //converte pra centavos;
		moeda100 = (int) (N/100);
		N = N%100;
		moeda50 = (int) (N/50);
		N = N%50;
		moeda25 = (int) (N/25);
		N = N%25;
		moeda10 = (int) (N/10);
		N = N%10;
		moeda5 = (int) (N/5);
		N = N%5;
		moeda1 = (int) N;
		
		System.out.print("NOTAS:\n");
		System.out.printf("%d nota(s) de R$ 100.00\n", nota100);
		System.out.printf("%d nota(s) de R$ 50.00\n", nota50);
		System.out.printf("%d nota(s) de R$ 20.00\n", nota20);
		System.out.printf("%d nota(s) de R$ 10.00\n", nota10);
		System.out.printf("%d nota(s) de R$ 5.00\n", nota5);
		System.out.printf("%d nota(s) de R$ 2.00\n", nota2);
		System.out.print("MOEDAS:\n");
		System.out.printf("%d moeda(s) de R$ 1.00\n", moeda100);
		System.out.printf("%d moeda(s) de R$ 0.50\n", moeda50);
		System.out.printf("%d moeda(s) de R$ 0.25\n", moeda25);
		System.out.printf("%d moeda(s) de R$ 0.10\n", moeda10);
		System.out.printf("%d moeda(s) de R$ 0.05\n", moeda5);
		System.out.printf("%d moeda(s) de R$ 0.01\n", moeda1);
	}
}

