package prova;

public class Filme {
	private String nome;
	private int mesLancamento;
	private int anoLancamento;
	private String nomeDiretor;
	private String genero; //letra minuscula
	private int duracao;
	private double preco; 
	
	Filme(String nome, String genero, int duracao, double preco) {
		setNome(nome);
		setGenero(genero);
		setDuracao(duracao);
		setPreco(preco);
	}
	
	//setters e getters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getMesLancamento() {
		return mesLancamento;
	}
	public void setMesLancamento(int mesLancamento) {
		this.mesLancamento = mesLancamento;
	}
	public int getAnoLancamento() {
		return anoLancamento;
	}
	public void setAnoLancamento(int anoLancamento) {
		this.anoLancamento = anoLancamento;
	}
	public String getNomeDiretor() {
		return nomeDiretor;
	}
	public void setNomeDiretor(String nomeDiretor) {
		this.nomeDiretor = nomeDiretor;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
