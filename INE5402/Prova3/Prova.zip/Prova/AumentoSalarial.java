package provaUri;

import java.util.Scanner;

//1048
public class AumentoSalarial {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		//recebo a entrada e transformo em double
		String entrada = input.next(); 
		double salario = Double.parseDouble(entrada);
	
		//calculo o reajuste
		double qtdeReajuste;
		
		if (salario <= 400.00) {
			qtdeReajuste = 15;
		} 
		else {
			if (salario <= 800.00) {
				qtdeReajuste = 12;
			} 
			else {
				if (salario <= 1200.00) {
					qtdeReajuste = 10;
				} 
				else {
					if (salario <= 2000.00) {
						qtdeReajuste = 07;
					}
					//> 2000.00
					else { 
						qtdeReajuste = 04;
					}
				}
			}
		}
		
		double reajuste = salario*(qtdeReajuste/100); 
		double salarioFinal = salario + reajuste;
	
		//trabalho os dados pra string com .2 
		String outNovoSalario = String.format("%.2f", salarioFinal);
		outNovoSalario = outNovoSalario.replace(',', '.');
		
		String outReajuste = String.format("%.2f", reajuste);
		outReajuste = outReajuste.replace(',', '.');
		
		System.out.printf("Novo salario: %s\n", outNovoSalario);
		System.out.printf("Reajuste ganho: %s\n", outReajuste);
		System.out.printf("Em percentual: %.0f %%\n", qtdeReajuste);
			
	}
}

