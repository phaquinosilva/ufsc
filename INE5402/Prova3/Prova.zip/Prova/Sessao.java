package prova;

public class Sessao {
	private int hora;
	private String data;
	private Filme filmeExibicao;
	private Sala salaExibicao;
	
	Sessao() {
	}
	
	//getters e setters
	public int getHora() {
		return hora;
	}
	public void setHora(int hora) {
		this.hora = hora;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Sala getSalaExibicao() {
		return salaExibicao;
	}
	public void setSalaExibicao(Sala salaExibicao) {
		this.salaExibicao = salaExibicao;
	}
	public Filme getFilmeExibicao() {
		return filmeExibicao;
	}
	public void setFilmeExibicao(Filme filmeExibicao) {
		this.filmeExibicao = filmeExibicao;
	}
	
	
}
