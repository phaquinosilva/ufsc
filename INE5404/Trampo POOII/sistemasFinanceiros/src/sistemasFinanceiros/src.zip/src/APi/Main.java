package APi;

public class Main {
	public static void main(String args[]) {
		new Main();
	}
	
	Main() {
		apiConnector = new ;
	}

	private final ApiConnector apiConnector;
	
	public IntraDay intraDay(String symbol, Market market)  {
	    String json = apiConnector.getRequest(new Symbol(symbol), Function.DIGITAL_CURRENCY_INTRADAY, market);
	    return IntraDay.from(market, json);
	}
}
