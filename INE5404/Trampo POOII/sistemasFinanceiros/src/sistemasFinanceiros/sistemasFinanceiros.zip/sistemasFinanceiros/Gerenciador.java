package sistemasFinanceiros;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;


public class Gerenciador implements ActionListener {
	private List<Empresa> empresasList;
	private Timer timerSeg;
	private int tempo;
	private Tela tela;
	
	Gerenciador() {
		empresasList = new ArrayList<>();
		
        timerSeg = new Timer(1000, this);
        timerSeg.start();
        tempo = (5*60)-1;
        
        tela = new Tela(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		tempo++;
		tela.ajustarNextCallLabel(tempo);
		
		if(tempo == 5*60) {
			callAPI();
		}
    }

	public void callAPI() {
		tempo = 0;
		
		for(Empresa emp : empresasList) {
			emp.fazRequest();
			
			String compraOuVende = emp.compraOuVende(); 
			//se for diferente de espere
			if(!compraOuVende.equals("espere")) {
				JFrame j = new JFrame();
				
				//ajusto a msg
				String mensagem = compraOuVende +" "+ emp.getName() +" Preco: "+emp.preco();
				
				JOptionPane.showMessageDialog(j, mensagem);
			}
		}
	}
	
	public void addEmpresasList(String sigla) {
		empresasList.add(new Empresa(sigla));
	}
	public void removeEmpresasList(String sigla) {
		if(empresasList.size() != 0) {
			for(Empresa emp : empresasList) {
				if(emp.getName().equals(sigla)) {
					empresasList.remove(emp);		
				}
			}
		}
	}
	public void removeAllEmpresasList() {
		empresasList.removeAll(empresasList);		
	}
	public List<String> getEmpresasListSiglas() {
		List<String> siglas = new ArrayList<>();
		
		for(Empresa emp : empresasList) {
			siglas.add(emp.getName());
		}
		
		return siglas;
	}
	public List<Empresa> getEmpresasList() {
		return empresasList;
	}
}