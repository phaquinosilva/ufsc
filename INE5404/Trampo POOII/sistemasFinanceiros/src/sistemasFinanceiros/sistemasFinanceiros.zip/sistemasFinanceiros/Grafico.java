package sistemasFinanceiros;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Grafico extends JPanel {
	private double[] ultimos = {0,0,0,0};
	private boolean pintar = false;
	private int[] altura = {0,0,0,0};
	
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.drawRect(100, 100, 100, 100);
        
        if(pintar) {
	        g.setColor(Color.BLUE);
			g.drawLine(100, (int)ultimos[0]+100, 300, (int)ultimos[1]+100);
	        
			g.setColor(Color.RED);
			g.drawLine(100, (int)ultimos[2]+100, 300, (int)ultimos[3]+100);
        }
    }
	
	public void printGrafico(double[] ultimos) {
		pintar = true;
		repaint();
	}
	
}
